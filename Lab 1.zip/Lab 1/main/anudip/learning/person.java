package main.anudip.learning;

public class person {
    String name = "Abhishek";
    int age = 21;
    int salary = 50000;

    public static void main(String[] args) {
        System.out.println("Test Successful");
    }
}
