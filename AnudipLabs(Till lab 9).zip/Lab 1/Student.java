public class Student {
    private String studentName;
    private String collegeName;
    private int studentID;

    public static void main(String[] args) {
        System.out.println("Successful");
    }
}
